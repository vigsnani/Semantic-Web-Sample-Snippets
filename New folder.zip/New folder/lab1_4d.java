package lab1_n;



import org.apache.jena.tdb.TDBFactory;
import org.apache.jena.util.FileManager;
import org.apache.commons.logging.Log;
import org.apache.jena.datatypes.xsd.XSDDatatype;
import org.apache.jena.query.Dataset;
import org.apache.jena.query.ReadWrite;

import java.io.*;


import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Property;
import org.apache.jena.rdf.model.Resource;

import org.apache.jena.vocabulary.VCARD;




public class lab1_4d{
	public static String defaultnamespace="http://utdallas/semclass/edu";

	  



public static void main(String []args){
	
	org.apache.log4j.Logger.getRootLogger().setLevel(org.apache.log4j.Level.OFF);
 String directory = "MyDatabases/Dataset1" ;
	   Dataset dataset = TDBFactory.createDataset(directory) ;
	   Model m=dataset.getNamedModel("myrdf");
	  
	  try{
	   String Namespace="http://utdallas/semclass#KevinLates";
	   String Name="Kevin L. Ates";
	   String email="atescomp@utdallas.edu";
	   String bday="April 1,1901";
	   String title="Part Time Lecturer";
	   
	   
	   
	   Resource kevin=m.createResource(Namespace);
	   kevin.addProperty(VCARD.FN,Name)
	   .addProperty(VCARD.TITLE,title)
	   .addProperty(VCARD.BDAY, bday)
	   .addProperty(VCARD.EMAIL, email);
	
	     } catch (Exception e) {
	    
	 
  }
	  finally
	  {
		  dataset.end();
	  }
	  try{
		  dataset.begin(ReadWrite.READ);
		  System.out.println("Loading FOAF Data..");
			InputStream inFoafInstance = FileManager.get().open("FOAFDATA.rdf");
			  System.out.print("Read the FOAF Data and is displayed in the three formats(XML,N-TRIPLE,N3). ");
			m.read(inFoafInstance, defaultnamespace);	
			dataset.commit();
	  }catch(Exception e){
	  }
	  finally{
		  dataset.end();
	  }
	  
	  try{
		  dataset.begin(ReadWrite.WRITE);
		  m=dataset.getNamedModel("myrdf");
				  FileOutputStream fileoutputStream = new FileOutputStream("Lab1_4_NBangaloreNaresh.xml");
				    FileOutputStream fileOutputStream1= new FileOutputStream("Lab1_4_NBangaloreNaresh.ntp");
				    FileOutputStream fileOutputStream2 = new FileOutputStream("Lab1_4_NBangaloreNaresh.n3");
				    m.write(fileoutputStream);
				    m.write(fileOutputStream2, "N-TRIPLE");
				    m.write(fileOutputStream1,"N3");
				    
				  
				    dataset.commit();
	  }
	  catch(Exception e){
		  
	  }
	  finally{
		  dataset.end();
	  }
}
}
	  

	  


